<!DOCTYPE html>
<html>
	<head>
		<title>Projet télémédecine</title>
		<meta charset="utf-8">
		<link rel="stylesheet">
</head>
<body>
	<h1>Projet télémédecine</h1>
	<?php
		$servername='localhost';
		$user='root';
		$password='';
		$dbname='sante';

		try{
			$dbco=new PDO("mysql:host=$servername; dbname=$dbname", $user, $password);
			$dbco->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

			$sql="CREATE TABLE patients(
				id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, 
				nom VARCHAR(30) NOT NULL,
				prenom VARCHAR(30) NOT NULL,
				email VARCHAR(50) NOT NULL,
				numero INT UNSIGNED NOT NULL,
				adresse VARCHAR(70) NOT NULL,
				ville VARCHAR(30) NOT NULL,
				codepostal INT UNSIGNED NOT NULL,
				secu INT UNSIGNED NOT NULL,
				username VARCHAR(10) NOT NULL,
				mdp VARCHAR(30) NOT NULL,
				UNIQUE(email))";
			$dbco->exec($sql);

			echo 'Table bien crééé !';
		}

		catch(PDOException $e){
			echo "Erreur: ".e->getMessage();
		}
	?>

	</body>
</html>
		try{
			$dbco=new PDO("mysql:host=$servername;dbname=$dbname",$user,$pass);
			$dbco->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
			//$dbco->beginTransaction();

			$nom="DU";
			$prenom="Bob";
			$adresse="Rue de soie";
			$ville="Nantes";
			$cp=40;
			$pays = "France";
			$mail = "bobdu@gmail.com";
			$sth=$dbco->prepare("
				INSERT INTO Clients(Nom,Prenom,Adresse,Ville,Codepostal,Pays,Mail)
					/*VALUES(:nom,:prenom,:adresse,:ville,:cp,:pays,:mail)*/
					VALUES(?,?,?,?,?,?,?)
			");
			/*$sth->bindValue(':nom',$nom);
			$sth->bindValue(':prenom',$prenom);
			$sth->bindValue(':adresse',$adresse);
			$sth->bindValue(':ville',$ville);
			$sth->bindValue(':cp',$cp,PDO::PARAM_INT);
			$sth->bindValue(':pays',$pays);
			$sth->bindValue(':mail',$mail);*/
			$sth->bindValue(1,$nom);
			$sth->bindValue(2,$prenom);
			$sth->bindValue(3,$adresse);
			$sth->bindValue(4,$ville);
			$sth->bindValue(5,$cp,PDO::PARAM_INT);
			$sth->bindValue(6,$pays);
			$sth->bindValue(7,$mail);

			$sth->execute();
			echo "Entrée ajoutée dans la table!";
			}	
			//$sth->execute(array($nom,$prenom,$adresse,$ville,$cp,$pays,$mail));
			/*
			$sth->execute(array(
			':nom'=> $nom,
			':prenom'=>$prenom,
			':adresse'=>$adresse,
			':ville'=>$ville,
			':cp'=>$cp,
			':pays'=>$pays,
			':mail'=>$mail,
			));
			$sql="CREATE TABLE Clients(
				Id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
				Nom VARCHAR(30) NOT NULL,
				Prenom VARCHAR(30) NOT NULL,
				Adresse VARCHAR (70) NOT NULL,
				Ville VARCHAR (30) NOT NULL,
				Codepostal INT UNSIGNED NOT NULL,
				Pays VARCHAR(30) NOT NULL,
				Mail VARCHAR(50) NOT NULL,
				DateInscrption TIMESTAMP,
				UNIQUE(Mail))";*/

			/*$sql="INSERT INTO 
			Clients(Nom,Prenom,Adresse,Ville,Codepostal,Pays,Mail)
					VALUES('FERREIRA','Alicia','9 avenue de saint maurice','Champigny',94500, 'France','alicia.f@etu.u-pec.fr')";*/ 

			/*$sql1="INSERT INTO 
			Clients(Nom,Prenom,Adresse,Ville,Codepostal,Pays,Mail)
					VALUES('DURAND','Victor','Rue des Acacias','Brest',29200, 'France','v.durant@gmail.com')";
			$dbco->exec($sql1);

			$sql2="INSERT INTO 
			Clients(Nom,Prenom,Adresse,Ville,Codepostal,Pays,Mail)
					VALUES('JOLY','Julia','Rue du Hameau','Lyon',69001, 'France','julia@gmail.com')";
			$dbco->exec($sql2);*/
			/*$sql="INSERT INTO 
			Clients(Nom,Prenom,Adresse,Ville,Codepostal,Pays,Mail)
					VALUES('$nom','$prenom','$adresse','$ville','$cp','$pays','$mail')";

			$dbco->exec($sql);
			//$dbco-> commit();*/
			/*echo 'Entrée ajoutée dans la table!';
		}*/

		catch(PDOException $e) {
				//$dbco->rollBack();
			echo "Erreur : ".$e-> getMessage();
		}
	?>
</body>
</html>
