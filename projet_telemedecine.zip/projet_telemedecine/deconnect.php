<?php
  // Initialisation de la session
  session_start();
  
  // Destruction de la session
  if(session_destroy())
  {
    // Redirection vers la page de connexion
    header("Location: indexmed.php");
  }
?>