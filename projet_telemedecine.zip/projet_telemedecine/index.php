<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <link rel="stylesheet" href="style.css" />
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
</head>
<head>

  <!-- /* Fonts -->

  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@900&family=Ubuntu:wght@300;400;700&display=swap" rel="stylesheet">

  <script src="https://kit.fontawesome.com/8cae91f94f.js" crossorigin="anonymous"></script>

  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>



  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.min.js" integrity="sha384-w1Q4orYjBQndcko6MimVbzY0tgp4pWB4lZ7lr30WKz0vr/aWKhXdBNmNb5D92v7s" crossorigin="anonymous"></script>

  <style>
    @import "https://use.fontawesome.com/releases/v5.5.0/css/all.css";

body {
background-image: url('https://connectedoctors.fr/wp-content/uploads/2021/01/93f35aaf2e_131667_telemedecine-c-ra2-studio-fotoliacom.jpg');
background-repeat: no-repeat;
background-attachment: fixed;
margin: 0;
padding: 40;
font-family: sans-serif;
background-size: cover;
font-family: 'Open Sans', sans-serif;
}

#title {
  color:  palevioletredd;
  text-align: center;
}

#title a {
  color: #ffffff;
}

.container-fluid{
  padding: 0% 15%;
}

.navbar {
  padding:  0 0 0rem;
}

.navbar-brand {
  font-family: Ubuntu;
  font-size: 2.5rem;
  font-weight: bolder;
}

.nav-item {
  padding: 0 18px;
}

.nav-link{
  font-size: 1.2rem;
  font-family: Montserrat;
}

.container-fluid{
  width: 100%;
  background-color: lightblue;
}

.container-fluid ul{
  width: 90%;
  text-align: right;
  position:  absolute;
}

.container-fluid ul li{
  list-style: none;
  display: inline-block;
}

.container-fluid ul li a{
  display: block;
  text-decoration: none;
  text-transform: uppercase;
  color: #ffff;
  font-size: 20px;
  font-family: 'Raleway', sans-serif;
  letter-spacing: 2px;
  font-weight: 500;
  padding: 5px;
}


  </style>

</head>

<body>

  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>


  <section id="title">

    <!-- Nav Bar -->
    <div class="container-fluid">
  <nav class="navbar navbar-expand-lg navbar-light">
     <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo01" aria-controls="navbarTogglerDemo01" aria-expanded="true" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

    <a class="navbar-brand" href=""> Docto'nect </a>
    <div id="logo">
    <img src="logo.png" alt="logo plat" width="90" ; height="90"/>
  </div>

  <div class="collapse navbar-collapse" id="navbarTogglerDemo01">
   
    <ul class="navbar-nav  ml-auto">
      <li class="nav-item">
        <a class="nav-link" href="accueil.html"> Accueil </a>
      </li>
       <li class="nav-item">
        <a class="nav-link" href=""> Mes rendez-vous </a>
      </li>
       <li class="nav-item">
        <a class="nav-link" href="deconnect.php"> Déconnexion </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="contact.html"> Nous contacter </a>
      </li>
     
    </ul>
  </div>
</nav>

</div>
</head>

<body>

<?php
  // Initialisation de la session
  session_start();
  // On vérifie si l'utilisateur est connecté, sinon on le redirige vers la page de connexion
  if(!isset($_SESSION["username"])){
    header("Location: accueil.html");
    exit(); 
  }  
?>


  <body>
    <div class="sucess" style="font-size: 20px;">
    <h1 style="font-size: 30px; color: darkblue;"> <br> Bienvenue <?php echo $_SESSION['username']; ?> dans votre espace personnel!</h1>
    <br>
    <br>
    <form method="POST" action="">
  <input type="submit" name="submit" value="Mes informations" style="background-color: royalblue; color: white;">
  </form>
  <br>

  <form method="POST" action="">
  <input type="submit" name="submit" value="Prise de rendez-vous" style="background-color: royalblue; color: white;">
  </form>
  <br>

   <form method="POST" action="TP2/teleconsultation.html">
  <input type="submit" name="submit" value="Espace video" style="background-color: royalblue; color: white;">
  </form>

  <br>

  <a style="font-size: 20px; color: white;" href="http://localhost:3000">Espace chat avec le professionnel</a>

  </div>
  </body>
</html>
 