var app = require('express')();
var http = require('http').Server(app);
var io = require('socket.io')(http);

app.get('/', function(req, res){
   res.sendFile(__dirname + '/Chat.html');
});

users = [];

// à chaque fois que qqn se connecte cette commande est exécuté
io.on('connection', function(socket){
   console.log('Un utilisateur est connecté');
   // console.log permet de confirmer dans le terminal 
   // qu'un utilisateur est connecté à la page

   //quand qqn se déconnecte cette partie est exécuté
   socket.on('disconnect', function () {
      console.log('Un utilisateur est déconnecté');
   });

   socket.on('setUser', function(data){
      console.log(data);
      
        if(users.indexOf(data) > -1){}
         else {
         socket.emit('userSet', {username: data});}
   });

   socket.on('msg', function(data){
      //Envoyer un message à tous
      io.sockets.emit('nvmsg', data);
   })
  });

//serveur http écoute sur le port 3000
http.listen(3000, function(){
   console.log('listening on *:3000');
});

