<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Se connecter espace médecins</title>
  <link rel="stylesheet" href="style.css" />
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
</head>
<head>

  <!-- /* Fonts -->

  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@900&family=Ubuntu:wght@300;400;700&display=swap" rel="stylesheet">

  <script src="https://kit.fontawesome.com/8cae91f94f.js" crossorigin="anonymous"></script>

  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>



  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.min.js" integrity="sha384-w1Q4orYjBQndcko6MimVbzY0tgp4pWB4lZ7lr30WKz0vr/aWKhXdBNmNb5D92v7s" crossorigin="anonymous"></script>

  <style>
    @import "https://use.fontawesome.com/releases/v5.5.0/css/all.css";

body {
background-image: url('https://connectedoctors.fr/wp-content/uploads/2021/01/93f35aaf2e_131667_telemedecine-c-ra2-studio-fotoliacom.jpg');
background-repeat: no-repeat;
background-attachment: fixed;
background-size: cover;
margin: 0;
padding: 40;
font-family: sans-serif;
background-size: cover;

}

.box-button {
  border-radius: 10px;
  background: royalblue;
  text-align: center;
  cursor: pointer;
  font-size: 19px;
  width: 40%;
  height: 51px;
  color: white;
}

.box {
  border: 10px solid cadetblue;
  padding: 30px 25px 10px 25px;
  background: white;
  margin: 30px auto;
  width: 760px;
}


#title {
  color:  palevioletredd;
  text-align: center;
}

#title a {
  color: #ffffff;
}

.container-fluid{
  padding: 0% 15%;
}

.navbar {
  padding:  0 0 0rem;
}

.navbar-brand {
  font-family: Ubuntu;
  font-size: 2.5rem;
  font-weight: bolder;
}

.nav-item {
  padding: 0 18px;
}

.nav-link{
  font-size: 1.2rem;
  font-family: Montserrat;
}

.container-fluid{
  width: 100%;
  background-color: lightblue;
}

.container-fluid ul{
  width: 90%;
  text-align: right;
}

.container-fluid ul li{
  list-style: none;
  display: inline-block;
}

.container-fluid ul li a{
  display: block;
  text-decoration: none;
  text-transform: uppercase;
  color: #ffff;
  font-size: 20px;
  font-family: 'Raleway', sans-serif;
  letter-spacing: 2px;
  font-weight: 500;
  padding: 5px;
}


  </style>

</head>

<body>

  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>


  <section id="title">

    <!-- Nav Bar -->
    <div class="container-fluid">
  <nav class="navbar navbar-expand-lg navbar-light">
     <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo01" aria-controls="navbarTogglerDemo01" aria-expanded="true" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

    <a id="bonbon" class="navbar-brand" href=""> Docto'nect </a>
    <div id="logo">
    <img src="logo.png" alt="logo plat" width="90" ; height="90"/>
  </div>

  <div class="collapse navbar-collapse" id="navbarTogglerDemo01">
   
    <ul class="navbar-nav  ml-auto">
      <li class="nav-item">
        <a class="nav-link" href="accueil.html"> Accueil </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="choix.php"> Se connecter </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="contact.html"> Nous contacter </a>
      </li>
    </ul>
  </div>
</nav>

</div>
</head>

<body>
<?php
require('configuration.php');
session_start();
if (isset($_POST['username'])){
  $username = stripslashes($_REQUEST['username']);
  $username = mysqli_real_escape_string($dbco, $username);
  $mdp = stripslashes($_REQUEST['mdp']);
  $mdp = mysqli_real_escape_string($dbco, $mdp);
  $sql = "SELECT * FROM `medecins` WHERE username='$username' and mdp='$mdp'";
  $resultat = mysqli_query($dbco,$sql) or die(mysql_error());
  $rows = mysqli_num_rows($resultat);
  if($rows==1){
      $_SESSION['username'] = $username;
      header("Location: indexmed.php");
  }else{
    $text = "Nom d'utilisateur ou mot de passe incorrect.";
  }
}
?>

<form class="box" action="" method="post" name="login">
<h1 class="box-logo box-title"></h1>
<h1 class="box-title" style="color: darkblue;">Connexion</h1>
<input type="text" class="box-input" name="username" placeholder="Nom d'utilisateur">
<input type="password" class="box-input" name="mdp" placeholder="Mot de passe">
<p></p>
<input type="submit" value="Connexion " name="submit" class="box-button">
<?php if (! empty($text)) { ?>
    <p class="errorMessage"><?php echo $text; ?></p>
<?php } ?>
</form>
</body>
</html>