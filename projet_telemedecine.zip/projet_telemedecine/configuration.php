<?php
// Informations d'identification
define('servername', 'localhost');
define('user', 'root');
define('pass', '');
define('dbname', 'sante');

// Connexion à la BDD santé  MySQL 
$dbco = mysqli_connect(servername, user, pass, dbname);
  
// Vérification de la connexion
if($dbco === false){
    die("Oupps il y a une erreur : impossibilité de se connecter. " . mysqli_connect_error());
}
?>